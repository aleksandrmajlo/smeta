-- Adminer 4.8.1 MySQL 5.7.33 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `accessories`;
CREATE TABLE `accessories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` bigint(20) DEFAULT NULL,
  `order` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `accessories` (`id`, `title`, `price`, `order`, `created_at`, `updated_at`) VALUES
(1,	'саморезы',	NULL,	0,	'2022-05-20 10:50:30',	'2022-05-20 10:50:30'),
(2,	'саморезы с термошайбами',	NULL,	0,	'2022-05-20 10:54:18',	'2022-05-20 10:54:18');

DROP TABLE IF EXISTS `accessorie_roof`;
CREATE TABLE `accessorie_roof` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `accessorie_id` int(10) unsigned NOT NULL,
  `roof_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `accessorie_roof` (`accessorie_id`,`roof_id`),
  KEY `accessorie_roof_accessorie_id_index` (`accessorie_id`),
  KEY `accessorie_roof_roof_id_index` (`roof_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `accessorie_roof` (`id`, `accessorie_id`, `roof_id`, `created_at`, `updated_at`) VALUES
(1,	1,	2,	NULL,	NULL),
(2,	1,	1,	NULL,	NULL),
(3,	2,	2,	NULL,	NULL);

DROP TABLE IF EXISTS `dopmaterials`;
CREATE TABLE `dopmaterials` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` bigint(20) DEFAULT NULL,
  `price_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'руб.' COMMENT 'По умолчанию руб. % м.п.',
  `order` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `dopmaterials` (`id`, `title`, `price`, `price_type`, `order`, `created_at`, `updated_at`) VALUES
(1,	'водосточная система',	12,	'м.п.',	0,	'2022-05-20 14:06:11',	'2022-05-20 14:11:36');

DROP TABLE IF EXISTS `examples`;
CREATE TABLE `examples` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `text` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Текст в листинге',
  `order` int(11) NOT NULL DEFAULT '0',
  `characteristics` json DEFAULT NULL COMMENT 'Характеристики',
  `prices` json DEFAULT NULL,
  `gallery` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `examples` (`id`, `title`, `text`, `order`, `characteristics`, `prices`, `gallery`, `created_at`, `updated_at`) VALUES
(1,	'title',	'text',	0,	'\"[{\\\"text\\\":\\\"\\\\u041f\\\\u0435\\\\u0440\\\\u0432\\\\u0430\\\\u044f\\\",\\\"value\\\":\\\"\\\\u0417\\\\u043d\\\\u0430\\\\u0447\\\\u0435\\\\u043d\\\\u0438\\\\u0435\\\"},{\\\"text\\\":\\\"\\\\u0412\\\\u0442\\\\u043e\\\\u0440\\\\u0430\\\\u044f\\\",\\\"value\\\":\\\"\\\\u0417\\\\u043d\\\\u0430\\\\u0447\\\\u0435\\\\u043d\\\\u0438\\\\u0435\\\"}]\"',	'\"[{\\\"text\\\":\\\"\\\\u0446\\\\u0435\\\\u043d\\\\u0430 1\\\",\\\"value\\\":\\\"\\\\u0437\\\\u043d\\\\u0430\\\\u0447\\\\u0435\\\\u043d\\\\u0438\\\\u0435\\\"},{\\\"text\\\":\\\"\\\\u0421\\\\u0440\\\\u043e\\\\u043a 1\\\",\\\"value\\\":\\\"\\\\u0437\\\\u043d\\\\u0430\\\\u0447\\\\u0435\\\\u043d\\\\u0438\\\\u0435\\\"}]\"',	'\"[\\\"images\\\\/uploads\\\\/84692844e1781fca4feea2fe51128073.jpg\\\",\\\"images\\\\/uploads\\\\/1717e447830cebc94337db03071df9d9.jpg\\\"]\"',	'2022-05-12 14:00:46',	'2022-05-12 14:12:00');

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `formroofs`;
CREATE TABLE `formroofs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order` int(11) NOT NULL DEFAULT '0',
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `formroofs` (`id`, `title`, `order`, `image`, `created_at`, `updated_at`) VALUES
(1,	'Арочная кровля',	2,	'images/uploads/83ec806742060dc2bcaef52b02142805.svg',	'2022-05-12 15:26:33',	'2022-05-20 07:05:40'),
(2,	'Полуарочная кровля',	3,	'images/uploads/e82b5cf0fad381858bda41f2aef4519b.svg',	'2022-05-12 15:26:52',	'2022-05-20 07:05:40'),
(3,	'2-скатная кровля',	1,	'images/uploads/b941cbc84d62436d2ba27d9e79473356.svg',	'2022-05-20 07:03:36',	'2022-05-20 07:05:40'),
(4,	'1-скатная кровля',	0,	'images/uploads/e66d5103c3d99db13036a53322db2685.svg',	'2022-05-20 07:05:14',	'2022-05-20 07:05:36'),
(5,	'4-скатная кровля',	4,	'images/uploads/29ce98f3e5cad634d483fb202364af26.svg',	'2022-05-20 07:06:40',	'2022-05-20 07:06:44');

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1,	'2014_10_12_000000_create_users_table',	1),
(2,	'2014_10_12_100000_create_password_resets_table',	1),
(3,	'2019_08_19_000000_create_failed_jobs_table',	1),
(4,	'2019_12_14_000001_create_personal_access_tokens_table',	1),
(5,	'2022_05_12_143741_create_tubes_table',	2),
(6,	'2022_05_12_150606_create_roofs_table',	3),
(7,	'2022_05_12_152558_create_paints_table',	4),
(8,	'2022_05_12_155056_create_examples_table',	5),
(9,	'2022_05_12_181641_create_formroofs_table',	6),
(10,	'2022_05_20_072221_create_trusssystems_table',	7),
(11,	'2022_05_20_073632_create_services_table',	8),
(12,	'2022_05_20_125454_create_obreshetkas_table',	9),
(13,	'2022_05_20_133120_create_accessories_table',	10),
(14,	'2022_05_20_154054_create_montaches_table',	11),
(15,	'2022_05_20_165820_create_dopmaterials_table',	12),
(16,	'2022_05_20_180601_create_photos_table',	13),
(17,	'2022_05_23_180830_create_roofelements_table',	14);

DROP TABLE IF EXISTS `montaches`;
CREATE TABLE `montaches` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` bigint(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `montaches` (`id`, `title`, `price`, `created_at`, `updated_at`) VALUES
(1,	'щебень',	200,	'2022-05-20 13:53:32',	'2022-05-20 13:54:14'),
(2,	'пескобетон для бетонирования столбов',	100,	'2022-05-20 13:53:44',	'2022-05-20 13:53:44'),
(3,	'винтовые сваи 76 мм',	100,	'2022-05-20 13:53:53',	'2022-05-20 13:53:53'),
(4,	'винтовые сваи 89 мм',	100,	'2022-05-20 13:54:04',	'2022-05-20 13:54:04');

DROP TABLE IF EXISTS `obreshetkas`;
CREATE TABLE `obreshetkas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` bigint(20) DEFAULT NULL,
  `order` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `obreshetkas` (`id`, `title`, `price`, `order`, `created_at`, `updated_at`) VALUES
(1,	'профильная труба 40х20 мм',	1000,	0,	'2022-05-20 10:02:20',	'2022-05-20 10:02:20'),
(2,	'профильная труба 40х40 мм',	2000,	0,	'2022-05-20 10:02:31',	'2022-05-20 10:02:31');

DROP TABLE IF EXISTS `paints`;
CREATE TABLE `paints` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` bigint(20) NOT NULL,
  `order` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `paints` (`id`, `title`, `price`, `order`, `created_at`, `updated_at`) VALUES
(1,	'Dali грунт-эмаль 3в1',	300,	0,	'2022-05-12 12:45:51',	'2022-05-12 12:45:51'),
(2,	'Эмаль Hammerite 5кг',	1000,	0,	'2022-05-20 10:25:39',	'2022-05-20 10:25:39');

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `photos`;
CREATE TABLE `photos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `roof_id` int(10) unsigned NOT NULL,
  `formroof_id` int(10) unsigned NOT NULL,
  `gallery` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `photos` (`id`, `roof_id`, `formroof_id`, `gallery`, `created_at`, `updated_at`) VALUES
(1,	2,	4,	'[\"images/uploads/ab0061435e9df4b332985af4cd91fd58.png\", \"images/uploads/7c2e4f0d0ba1af48415bd14761bf9fcf.png\"]',	'2022-05-20 15:50:00',	'2022-05-20 17:33:52'),
(3,	1,	4,	'[\"images/uploads/8933dd52b1aeff57ddaa522d7785ffca.jpg\"]',	'2022-05-20 17:48:54',	'2022-05-20 17:48:54'),
(4,	1,	3,	'[\"images/uploads/418b50ae96cac85dd8ac88bf2fa403e8.jpg\", \"images/uploads/23be891fd747082e79b120b2efa9da7b.png\"]',	'2022-05-20 17:49:31',	'2022-05-20 17:49:34');

DROP TABLE IF EXISTS `roofelements`;
CREATE TABLE `roofelements` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` bigint(20) DEFAULT NULL,
  `roof_id` int(10) unsigned NOT NULL,
  `order` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `roofelements` (`id`, `title`, `price`, `roof_id`, `order`, `created_at`, `updated_at`) VALUES
(1,	'80*80',	1000,	1,	0,	'2022-05-23 15:39:47',	'2022-05-23 15:39:47'),
(2,	'60*60',	800,	2,	0,	'2022-05-23 15:40:04',	'2022-05-23 15:42:20'),
(3,	'80*80',	1000,	2,	0,	'2022-05-23 15:59:29',	'2022-05-23 15:59:29');

DROP TABLE IF EXISTS `roofs`;
CREATE TABLE `roofs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` bigint(20) DEFAULT NULL,
  `order` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `roofs` (`id`, `title`, `price`, `order`, `created_at`, `updated_at`) VALUES
(1,	'Сотовый поликарбонат',	800,	0,	'2022-05-12 12:21:42',	'2022-05-23 15:14:25'),
(2,	'КАРБОГЛАСС ПРЕМИУМ',	950,	1,	'2022-05-12 12:23:34',	'2022-05-23 15:14:53');

DROP TABLE IF EXISTS `services`;
CREATE TABLE `services` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` bigint(20) DEFAULT '0',
  `price_type` varchar(155) COLLATE utf8mb4_unicode_ci DEFAULT 'руб.',
  `default` bigint(20) NOT NULL DEFAULT '0' COMMENT 'По умолчанию 1,0 значит цену считам',
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `services` (`id`, `title`, `price`, `price_type`, `default`, `type`, `created_at`, `updated_at`) VALUES
(1,	'проектирование навеса для подбора',	NULL,	'%',	1,	'1',	'2022-05-20 05:03:25',	'2022-05-20 06:08:54'),
(2,	'материалов и определения конструктивных',	NULL,	'%',	1,	'1',	'2022-05-20 06:09:02',	'2022-05-20 06:09:02'),
(3,	'погрузка, доставка и разгрузка материалов',	5000,	'руб.',	0,	'5',	'2022-05-20 06:21:49',	'2022-05-20 06:25:45'),
(4,	'погрузка, доставка и разгрузка материалов',	7000,	'руб.',	0,	'5',	'2022-05-20 06:22:04',	'2022-05-20 06:25:38'),
(5,	'погрузка, доставка и разгрузка материалов',	9500,	'руб.',	0,	'5',	'2022-05-20 06:22:34',	'2022-05-20 06:22:34'),
(6,	'под ключ',	10,	'%',	0,	'6',	'2022-05-20 06:26:22',	'2022-05-20 06:26:22');

DROP TABLE IF EXISTS `trusssystems`;
CREATE TABLE `trusssystems` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` bigint(20) DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `trusssystems` (`id`, `title`, `price`, `type`, `created_at`, `updated_at`) VALUES
(1,	'40 х 20',	NULL,	'2',	'2022-05-20 04:29:53',	'2022-05-20 04:29:53'),
(2,	'еще размер',	NULL,	'1',	'2022-05-20 04:30:56',	'2022-05-20 04:30:56'),
(3,	'10*10',	NULL,	'1',	'2022-05-20 09:51:07',	'2022-05-20 09:51:07');

DROP TABLE IF EXISTS `tubes`;
CREATE TABLE `tubes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` bigint(20) DEFAULT NULL,
  `type` varchar(11) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `type_rigel` varchar(11) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tubes` (`id`, `title`, `price`, `type`, `type_rigel`, `created_at`, `updated_at`) VALUES
(1,	'60*60',	10000,	'1',	NULL,	'2022-05-12 11:54:10',	'2022-05-12 11:54:10'),
(2,	'80*80',	20000,	'1',	NULL,	'2022-05-12 11:56:16',	'2022-05-12 11:56:16'),
(3,	'100*100',	30000,	'1',	NULL,	'2022-05-12 11:56:32',	'2022-05-20 04:03:30'),
(4,	'ригель 1',	NULL,	'2',	'1',	'2022-05-20 04:07:08',	'2022-05-23 12:49:05'),
(5,	'ригель 2',	NULL,	'2',	'2',	'2022-05-20 07:37:43',	'2022-05-23 12:49:34');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1,	'info@pera-media.ru',	'info@pera-media.ru',	NULL,	'$2y$10$CgiD1D5PMbWGwDwb1Wyto.33zEaY/vRy50nv7ih4T3T4zxWGR7w2m',	'YnZ3KsthFulFps2tscXITheClZgN8ttCt0tYZrwKfcb9EsyA4LqKly7aXtTK',	'2022-05-12 09:55:50',	'2022-05-12 09:55:50');

-- 2022-05-23 20:54:35
